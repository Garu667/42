/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_grid.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saidriss <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/21 10:37:01 by saidriss          #+#    #+#             */
/*   Updated: 2024/09/21 17:24:20 by saidriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	while (*str)
		write(1, str++, 1);
}

void	print_row(int grid[4][4], int row)
{
	int	i;
	int	c;

	i = 0;
	while (i < 4)
	{
		c = grid[row][i] + '0';
		write(1, &c, 1);
		if (i < 3)
			write(1, " ", 1);
		i++;
	}
	write(1, "\n", 1);
}

void	print_grid(int grid[4][4])
{
	int	i;

	i = 0;
	while (i < 4)
	{
		print_row(grid, i);
		i++;
	}
}
