/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve_grid.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saidriss <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/21 14:14:35 by saidriss          #+#    #+#             */
/*   Updated: 2024/09/21 17:53:45 by saidriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_all(int grid[4][4], int *restraints);

int	valid_input(char *input, int *params)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < 16)
	{
		while (input[j] == ' ')
			j++;
		if (input[j] >= '1' && input[j] <= '4')
		{
			params[i] = input[j] - '0';
			i++;
			j++;
		}
		else
			return (0);
	}
	return (1);
}

void	get_row(int grid[4][4], int row, int *line)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		line[i] = grid[row][i];
		i++;
	}
}

void	get_col(int grid[4][4], int col, int *line)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		line[i] = grid[i][col];
		i++;
	}
}

int	already_here(int grid[4][4], int row, int col, int nb)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		if (grid[row][i] == nb || grid[i][col] == nb)
			return (0);
		i++;
	}
	return (1);
}

int	solve_puzzle(int grid[4][4], int *restraints, int row, int col)
{
	int	nb;

	if (row == 4)
		return (check_all(grid, restraints));
	if (col == 4)
		return (solve_puzzle(grid, restraints, row + 1, 0));
	nb = 1;
	while (nb <= 4)
	{
		if (already_here(grid, row, col, nb))
		{
			grid[row][col] = nb;
			if (solve_puzzle(grid, restraints, row, col + 1))
				return (1);
			grid[row][col] = 0;
		}
		nb++;
	}
	return (0);
}
