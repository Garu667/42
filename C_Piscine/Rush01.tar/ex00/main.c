/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saidriss <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/21 10:39:02 by saidriss          #+#    #+#             */
/*   Updated: 2024/09/21 18:15:23 by saidriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		solve_puzzle(int grid[4][4], int *restraints, int row, int col);

int		print_grid(int grid[4][4]);

void	ft_putstr(char *str);

int		valid_input(char *input, int *params);

int	ft_error(void)
{
	ft_putstr("Error\n");
	return (1);
}

int	main(int ac, char **av)
{
	int	grid[4][4];
	int	params[16];
	int	i;
	int	j;

	if (ac != 2 || !valid_input(av[1], params))
		ft_error();
	i = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			grid[i][j] = 0;
			j++;
		}
		i++;
	}
	if (!solve_puzzle(grid, params, 0, 0))
		ft_putstr("Error\n");
	else
		print_grid(grid);
	return (0);
}
