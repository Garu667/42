/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: saidriss <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/21 14:28:03 by saidriss          #+#    #+#             */
/*   Updated: 2024/09/21 15:26:58 by saidriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	get_col(int grid[4][4], int col, int *line);

void	get_row(int grid[4][4], int row, int *line);

int	check_dir(int *line, int restraint)
{
	int	i;
	int	max;
	int	visible;

	i = 0;
	max = 0;
	visible = 0;
	while (i < 4)
	{
		if (line[i] > max)
		{
			max = line[i];
			visible++;
		}
		i++;
	}
	return (visible == restraint);
}

int	check_col(int grid[4][4], int *restraint)
{
	int	line[4];
	int	i;

	i = 0;
	while (i < 4)
	{
		get_col(grid, i, line);
		if (!check_dir(line, restraint[i]))
			return (0);
		i++;
	}
	return (1);
}

int	check_row(int grid[4][4], int *restraint, int range)
{
	int	line[4];
	int	i;

	i = 0;
	while (i < 4)
	{
		get_row(grid, i, line);
		if (!check_dir(line, restraint[i + range]))
			return (0);
		i++;
	}
	return (1);
}

int	check_all(int grid[4][4], int *restraints)
{
	if (!check_col(grid, restraints))
		return (0);
	if (!check_col(grid, restraints + 4))
		return (0);
	if (!check_row(grid, restraints, 8))
		return (0);
	if (!check_row(grid, restraints, 12))
		return (0);
	return (1);
}
