from mazegen.algo.base import BaseSolver

NORTH = 0b0001
EAST  = 0b0010
SOUTH = 0b0100
WEST  = 0b1000


def _heuristic(p1: tuple[int, int], p2: tuple[int, int]) -> int:
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])


def _can_move(
    grid: list[list[int]],
    cell: tuple[int, int],
    neighbor: tuple[int, int],
) -> bool:
    cx, cy = cell
    nx, ny = neighbor
    if ny == cy + 1:
        return not (grid[cy][cx] & SOUTH)
    elif ny == cy - 1:
        return not (grid[cy][cx] & NORTH)
    elif nx == cx + 1:
        return not (grid[cy][cx] & EAST)
    elif nx == cx - 1:
        return not (grid[cy][cx] & WEST)
    return False


def _get_accessible_neighbors(
    grid: list[list[int]],
    cell: tuple[int, int],
    width: int,
    height: int,
) -> list[tuple[int, int]]:
    x, y = cell
    candidates = []
    if x > 0:
        candidates.append((x - 1, y))
    if x < width - 1:
        candidates.append((x + 1, y))
    if y > 0:
        candidates.append((x, y - 1))
    if y < height - 1:
        candidates.append((x, y + 1))
    return [n for n in candidates if _can_move(grid, cell, n)]


def _reconstruct_path(
    came_from: dict[tuple[int, int], tuple[int, int]],
    entry: tuple[int, int],
    exit_: tuple[int, int],
) -> list[str]:
    path = []
    current = exit_
    while current != entry:
        previous = came_from[current]
        cx, cy = current
        px, py = previous
        if cy == py + 1:
            path.append('S')
        elif cy == py - 1:
            path.append('N')
        elif cx == px + 1:
            path.append('E')
        else:
            path.append('W')
        current = previous
    path.reverse()
    return path


class A_Star(BaseSolver):
    """A* solver"""

    def solve(self) -> list[str]:
        """Resolve the maze using A*.

        Returns:
            List of direction ['N','E','S','W'] or nothing
        """
        open_list: list[tuple[int, int, tuple[int, int]]] = []
        heappush(open_list, (0, 0, self.entry))

        came_from: dict[tuple[int, int], tuple[int, int]] = {}
        g_score: dict[tuple[int, int], int] = {self.entry: 0}

        while open_list:
            _, g, current = heappop(open_list)

            if current == self.exit_:
                return _reconstruct_path(came_from, self.entry, self.exit_)

            if g > g_score.get(current, float('inf')):
                continue

            for neighbor in _get_accessible_neighbors(
                self.grid, current, self.width, self.height
            ):
                g_new = g + 1
                if g_new < g_score.get(neighbor, float('inf')):
                    g_score[neighbor] = g_new
                    f = g_new + _heuristic(neighbor, self.exit_)
                    came_from[neighbor] = current
                    heappush(open_list, (f, g_new, neighbor))

        return []
